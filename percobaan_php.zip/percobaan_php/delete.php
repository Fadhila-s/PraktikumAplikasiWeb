<?php
include 'config.php';
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "DELETE FROM akun_terdaftar WHERE password='123frte'";

if ($conn->query($sql) === TRUE) {
    echo "Data berhasil diperbarui";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>