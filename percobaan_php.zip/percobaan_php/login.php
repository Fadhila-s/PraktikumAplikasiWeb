<?php
include 'config.php';

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Periksa apakah form dikirim dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["email"])) {
        $email = $_POST["email"];

        // Query untuk memeriksa apakah email yang dimasukkan cocok dengan salah satu email di database
        $query = "SELECT * FROM akun_terdaftar WHERE email = ?";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "Login berhasil! Redirect ke halaman selanjutnya...";
                exit();
            } else {
                echo "Email tidak ditemukan!";
            }

            $stmt->close();
        } else {
            echo "Query gagal!";
        }
    } else {
        echo "Harap isi email!";
    }
} else {
    echo "Form tidak dikirim dengan metode POST!";
}

// Tutup koneksi
$conn->close();
?>
